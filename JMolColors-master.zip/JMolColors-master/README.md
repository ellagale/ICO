## JMol RGB color tuples and Hex color codes

This is a .csv containing information on the colors used in JMol and VisIt visualization tool for atom types.

For illustration of how to use to make colors in Matplotlib correspond to these atom colors, see my [blog post](http://corysimon.github.io/articles/atom-coloring-in-matplotlib/).
